let Employee = require('./employee')
let Branch = require('./branch')

result.Employee = Employee
result.Branch = Branch