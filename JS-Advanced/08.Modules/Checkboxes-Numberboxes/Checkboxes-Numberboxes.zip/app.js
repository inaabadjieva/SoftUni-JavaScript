let Checkbox = require('./checkbox.js')
let Numberbox = require('./numberbox.js')

result.Checkbox = Checkbox
result.Numberbox = Numberbox
// class Checkbox {
// 	constructor(label, selector){
// 		this._label = label
// 		this._elements = $(selector)
// 		this._value = this._elements.is(':checked')

// 		let that = this
// 		this._elements.on('change', function(){
// 			that.value = $(this).is(':checked')
// 		})
// 	}
// 	get label(){
// 		return this._lable
// 	}
// 	get elements(){
// 		return this._elements
// 	}
// 	get value(){
// 		return this._value
// 	}
// 	set value(value){
// 		if(typeof value  !== 'boolean'){
// 			throw new Error
// 		}
// 		this._value = value 
// 		this._elements.each(function(index, elem){
// 			$(elem).prop('checked', value)
// 		})
// 	}
// }

// class Numberbox {
// 	constructor(label, selector, minValue, maxValue){
// 		this._label = label
// 		this._elements = $(selector)
// 		this._minValue = minValue
// 		this._maxValue = maxValue
// 		this._value = this._elements.val()

// 		let that = this
// 		this._elements.on('change', function(){
// 			that.value = $(this).val()
// 		})
// 	}
// 	get label(){
// 		return this._label
// 	}
// 	get elements(){
// 		return this._elements
// 	}
// 	get value(){
// 		return this._value
// 	}
// 	set value(value){
// 		if(value <= this._minValue || value >= this._maxValue){
// 			throw new Error
// 		}
// 		this._value = value
// 		this._elements.each(function(index, elem){	
// 			$(elem).val(value)	
// 		}) 
// 	}
// }

// let check = new Checkbox("Is Married:","#married");
// console.log(check.value);
// let number = new Numberbox("Age:","#age",1,100);
// console.log(number.value);
// let checkbox = $('#married');
// let numberbox = $('#age');
// checkbox.on('change',()=>console.log(check.value));
// numberbox.on('change',()=>console.log(number.value));