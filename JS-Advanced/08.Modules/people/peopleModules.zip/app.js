let Employee = require('./employee')
let Junior = require('./junior')
let Senior = require('./senior')
let Manager = require('./manager')

result.Employee = Employee
result.Junior = Junior
result.Senior = Senior
result.Manager = Manager

