result.Person = require('./person')
result.Post = require('./post')